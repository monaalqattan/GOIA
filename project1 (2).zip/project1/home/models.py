from django.db import models

# Create your models here.
class Artifact(models.Model):
    ImagePath = models.ImageField(upload_to='uploads/', default="()")
    Description = models.TextField(blank=True, default='')
    Name = models.CharField(max_length=200, default='')
    full_type_name = models.CharField(max_length=100, default='')
    full_era_name = models.CharField(max_length=100, default='')
    is_checked = models.CharField(max_length=10, choices=[('done', 'Done'), ('pending', 'Pending')], default='pending')
    type_abbr = models.CharField(max_length=10, blank=True, default='')
    era_abbr = models.CharField(max_length=10, blank=True, default='')

    class Meta:
        db_table = 'Artifacts'
class EraAbbreviations(models.Model):
    EraAbbr = models.CharField(max_length=255)
    EraName = models.CharField(max_length=255, default='')

    class Meta:
        db_table = 'EraAbbreviations'
        managed = False  # Django لن يدير هذا الجدول، لن ينشئ أو يعدل هيكله

    def str(self):
        return self.EraName
class TypeAbbreviations(models.Model):
    TypeAbbr = models.CharField(max_length=255)
    TypeName = models.CharField(max_length=255, default='')
    class Meta:
        db_table = 'TypeAbbreviations'
        managed = False 
        
    def str(self):
        return self.TypeName