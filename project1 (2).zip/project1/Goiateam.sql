﻿-- إنشاء قاعدة البيانات إذا لم تكن موجودة
IF NOT EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = 'ArchaeologyDB')
BEGIN
    CREATE DATABASE ArchaeologyDB;
END
GO

USE ArchaeologyDB;

-- إنشاء جدول اختصارات الأنواع
IF OBJECT_ID('TypeAbbreviations', 'U') IS NULL
BEGIN
    CREATE TABLE TypeAbbreviations (
        TypeID INT PRIMARY KEY IDENTITY,
        TypeName VARCHAR(255) NOT NULL,
        TypeAbbr VARCHAR(2) NOT NULL
    );
END
GO

-- إدخال بيانات أساسية في جدول اختصارات الأنواع
MERGE TypeAbbreviations AS target
USING (VALUES
    ('Statues and Sculptures', 'SS'),
    ('Coffins', 'CF'),
    ('Mummies', 'MM'),
    ('Writings, Inscriptions, Papyri, and Scrolls', 'WP'),
    ('Masks', 'MS'),
    ('Stone Engravings', 'SE'),
    ('Jewelry', 'JW'),
    ('Textiles', 'TX'),
    ('Weapons', 'WN'),
    ('Tools and Implements', 'TI'),
    ('Medical Tools', 'MT'),
    ('Ceramics and Pottery', 'CP'),
    ('Coins', 'CN'),
    ('Paintings', 'PT'),
    ('Architectural Fragments', 'AF')
) AS source (TypeName, TypeAbbr)
ON target.TypeAbbr = source.TypeAbbr
WHEN NOT MATCHED BY TARGET THEN
    INSERT (TypeName, TypeAbbr) VALUES (source.TypeName, source.TypeAbbr);
GO

-- إنشاء جدول اختصارات العصور
IF OBJECT_ID('EraAbbreviations', 'U') IS NULL
BEGIN
    CREATE TABLE EraAbbreviations (
        EraID INT PRIMARY KEY IDENTITY,
        EraName VARCHAR(255) NOT NULL,
        EraAbbr VARCHAR(2) NOT NULL
    );
END
GO

-- إدخال بيانات أساسية في جدول اختصارات العصور
MERGE EraAbbreviations AS target
USING (VALUES
    ('Old Kingdom', 'OK'),
    ('Middle Kingdom', 'MK'),
    ('New Kingdom', 'NK'),
    ('Late Period', 'LP'),
    ('Ptolemaic Period', 'PP'),
    ('Roman Period', 'RP'),
    ('Islamic Period to Ottoman Rule', 'IO'),
    ('Modern Egypt', 'ME')
) AS source (EraName, EraAbbr)
ON target.EraAbbr = source.EraAbbr
WHEN NOT MATCHED BY TARGET THEN
    INSERT (EraName, EraAbbr) VALUES (source.EraName, source.EraAbbr);
GO

-- إنشاء جدول القطع الأثرية
IF OBJECT_ID('Artifacts', 'U') IS NULL
BEGIN
    CREATE TABLE Artifacts (
        ArtifactID INT PRIMARY KEY IDENTITY,
        UniqueID VARCHAR(255) UNIQUE NOT NULL,
        Name VARCHAR(255) NOT NULL,
        Description TEXT,
        type_abbr VARCHAR(2),
        era_abbr VARCHAR(2),
        item_number INT,
        full_type_name VARCHAR(255),
        full_era_name VARCHAR(255)
    );
END
GO

-- حذف جداول FullTypeName و FullEraName إذا كانت موجودة
IF OBJECT_ID('FullTypeName', 'U') IS NOT NULL
    DROP TABLE FullTypeName;
GO

IF OBJECT_ID('FullEraName', 'U') IS NOT NULL
    DROP TABLE FullEraName;
GO

-- حذف التريجر إذا كان موجوداً
IF OBJECT_ID('trg_UpdateUniqueID_OnInsert', 'TR') IS NOT NULL
    DROP TRIGGER trg_UpdateUniqueID_OnInsert;
GO

IF OBJECT_ID('trg_UpdateUniqueID_OnUpdate', 'TR') IS NOT NULL
    DROP TRIGGER trg_UpdateUniqueID_OnUpdate;
GO

-- إنشاء تريجر لتحديث UniqueID عند الإدخال
CREATE TRIGGER trg_UpdateUniqueID_OnInsert
ON Artifacts
AFTER INSERT
AS
BEGIN
    -- تحديث item_number والـ UniqueID بعد إدخال بيانات جديدة
    WITH ItemNumbers AS (
        SELECT 
            ArtifactID,
            type_abbr,
            era_abbr,
            ROW_NUMBER() OVER (PARTITION BY type_abbr, era_abbr ORDER BY ArtifactID) AS item_number
        FROM Artifacts
    )
    UPDATE a
    SET a.item_number = inbr.item_number,
        a.UniqueID = CONCAT(a.type_abbr, '-', a.era_abbr, '-', RIGHT('000000' + CAST(a.item_number AS VARCHAR(6)), 6)),
        a.full_type_name = (SELECT TypeName FROM TypeAbbreviations WHERE TypeAbbr = a.type_abbr),
        a.full_era_name = (SELECT EraName FROM EraAbbreviations WHERE EraAbbr = a.era_abbr)
    FROM Artifacts a
    INNER JOIN ItemNumbers inbr ON a.ArtifactID = inbr.ArtifactID;
END
GO

-- إنشاء تريجر لتحديث UniqueID عند التحديث
CREATE TRIGGER trg_UpdateUniqueID_OnUpdate
ON Artifacts
AFTER UPDATE
AS
BEGIN
    -- تحديث item_number والـ UniqueID بعد تحديث بيانات موجودة
    WITH ItemNumbers AS (
        SELECT 
            ArtifactID,
            type_abbr,
            era_abbr,
            ROW_NUMBER() OVER (PARTITION BY type_abbr, era_abbr ORDER BY ArtifactID) AS item_number
        FROM Artifacts
    )
    UPDATE a
    SET a.item_number = inbr.item_number,
        a.UniqueID = CONCAT(a.type_abbr, '-', a.era_abbr, '-', RIGHT('000000' + CAST(a.item_number AS VARCHAR(6)), 6)),
        a.full_type_name = (SELECT TypeName FROM TypeAbbreviations WHERE TypeAbbr = a.type_abbr),
        a.full_era_name = (SELECT EraName FROM EraAbbreviations WHERE EraAbbr = a.era_abbr)
    FROM Artifacts a
    INNER JOIN ItemNumbers inbr ON a.ArtifactID = inbr.ArtifactID;
END
GO

-- عرض البيانات للتأكد من التحديثات
SELECT * FROM Artifacts;
