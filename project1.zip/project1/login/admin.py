from django.contrib import admin
from django.contrib import admin
from .models import LoginAttempt

@admin.register(LoginAttempt)
class LoginAttemptAdmin(admin.ModelAdmin):
    list_display = ('username', 'success', 'timestamp', 'user')
    list_filter = ('success', 'timestamp')
    search_fields = ('username',)

# Register your models here.
