from django.urls import path , include
from . import views
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    path ('', views.Loginpage , name= 'Loginpage' ),
  #  path ('Home',views.Home , name = 'Home'),
     path('description/<path:image_path>/', views.description_view, name='description'),
    # path('description/<str:image_path>/', views.description_view, name='description'),
  #   path('descriptions/', views.DescriptionListCreateView.as_view(), name='description-list-create'),
   # path('descriptions/<str:image_path>/', views.DescriptionDetailView.as_view(), name='description-detail'),

]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)