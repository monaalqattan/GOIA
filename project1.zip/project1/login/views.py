from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from .forms import CustomLoginForm
from .models import LoginAttempt
from django.utils import timezone
from django.shortcuts import render, get_object_or_404
from home.models import TypeAbbreviations, EraAbbreviations
from home.models import Artifact
from django.db import connection


def Loginpage(request):
    if request.method == 'POST':
        form = CustomLoginForm(data=request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                # تسجيل محاولة تسجيل الدخول
                LoginAttempt.objects.create(
                    user=user,
                    username=username,
                    success=True,
                    timestamp=timezone.now()
                )
                return redirect('home')  # أعد توجيه المستخدم إلى الصفحة الرئيسية أو أي صفحة أخرى
            else:
                # تسجيل محاولة تسجيل الدخول غير الناجحة
                LoginAttempt.objects.create(
                    user=None,
                    username=username,
                    success=False,
                    timestamp=timezone.now()
                )
                print(f"Failed login attempt for {username} recorded.")
    else:
        form = CustomLoginForm()
    
    return render(request, 'login.html', {'form': form})
def description_view(request, image_path):
    #   استخدام get_object_or_404 لضمان العثور على القطعة أو عرض خطأ 404
      artifact = get_object_or_404(Artifact, ImagePath=image_path)
    
      if request.method == 'POST':
        # تحديث الحقول من النموذج المرسل
        artifact.ImagePath = request.POST.get('imagepath', artifact.ImagePath)
        artifact.Name = request.POST.get('name', artifact.Name)
        artifact.full_type_name = request.POST.get('type', artifact.full_type_name)
        artifact.full_era_name = request.POST.get('era', artifact.full_era_name)
        artifact.Description = request.POST.get('description', artifact.Description)
        artifact.is_checked = request.POST.get('is_checked', artifact.is_checked)
        
        # تحديث اختصار النوع
        type_name = artifact.full_type_name
        with connection.cursor() as cursor:
            cursor.execute("SELECT TypeAbbr FROM TypeAbbreviations WHERE TypeName = %s", [type_name])
            result = cursor.fetchone()
            artifact.type_abbr = result[0] if result else ''
        
    #     # تحديث اختصار العصر
        era_name = artifact.full_era_name
        with connection.cursor() as cursor:
            cursor.execute("SELECT EraAbbr FROM EraAbbreviations WHERE EraName = %s", [era_name])
            result = cursor.fetchone()
            artifact.era_abbr = result[0] if result else ''
        
        # حفظ التحديثات
        artifact.save()
        
        # إعادة توجيه المستخدم إلى الصفحة الرئيسية بعد الحفظ
        return redirect('home')

    # عرض النموذج مع البيانات الحالية
      return render(request, 'description.html', {'artifact': artifact})
