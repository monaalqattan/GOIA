from django.shortcuts import render
from .models import Artifact

# Create your views here.
def home(request):
    return render(request,'home.html',{'image':Artifact.objects.all()})
