from django.urls import path , include
from . import views
#from views import upload_image
from django.conf import settings
from django.conf.urls.static import static
from .views import Artifact

urlpatterns = [


 path('', views.home, name='home'),
#path('images/', views.ImageListCreateView.as_view(), name='image-list-create'),
#path('images/<str:image_path>/', views.ImageDetailView.as_view(), name='image-detail'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)