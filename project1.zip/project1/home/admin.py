from django.contrib import admin
from .models import Artifact
# Register your models here.
admin.site.register(Artifact)
